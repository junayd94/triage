import { Component } from '@angular/core';
import { Router } from '@angular/router';

type Side = 'front' | 'back';

interface AnatomyPoint {
  id: string; // unique route id, e.g. "head-front"
  label: string; // tooltip label
  x: number; // viewBox x coordinate
  y: number; // viewBox y coordinate
}

@Component({
  selector: 'app-anatomy',
  standalone: false,
  templateUrl: './anatomy.component.html',
  styleUrl: './anatomy.component.scss'
})
export class AnatomyComponent {

  constructor(private router: Router) { }

  side: Side = 'front';


  // Coordinates are aligned to the SVG viewBox: 300 (w) x 800 (h)
  frontPoints: AnatomyPoint[] = [
    { id: 'head-front', label: 'Head (Front)', x: 150, y: 70 },
    { id: 'lungs-front', label: 'Lungs (Front)', x: 150, y: 210 },
    { id: 'heart-front', label: 'Heart (Front)', x: 140, y: 240 },
    { id: 'stomach-front', label: 'Stomach (Front)', x: 150, y: 300 },
    { id: 'kidneys-front', label: 'Kidneys (Front)', x: 150, y: 340 },
    { id: 'pelvis-front', label: 'Pelvic Region', x: 150, y: 400 },
    { id: 'arm-left-front', label: 'Left Arm', x: 70, y: 260 },
    { id: 'arm-right-front', label: 'Right Arm', x: 230, y: 260 },
    { id: 'hand-left-front', label: 'Left Hand', x: 40, y: 440 },
    { id: 'hand-right-front', label: 'Right Hand', x: 260, y: 440 },
    { id: 'leg-left-front', label: 'Left Leg', x: 120, y: 560 },
    { id: 'leg-right-front', label: 'Right Leg', x: 180, y: 560 },
    { id: 'foot-left-front', label: 'Left Foot', x: 120, y: 760 },
    { id: 'foot-right-front', label: 'Right Foot', x: 180, y: 760 }
  ];


  backPoints: AnatomyPoint[] = [
    { id: 'head-back', label: 'Head (Back)', x: 150, y: 70 },
    { id: 'lungs-back', label: 'Lungs (Back)', x: 150, y: 210 },
    { id: 'heart-back', label: 'Heart Area (Back)', x: 150, y: 240 },
    { id: 'stomach-back', label: 'Abdomen (Back)', x: 150, y: 300 },
    { id: 'kidneys-back', label: 'Kidneys (Back)', x: 150, y: 340 },
    { id: 'pelvis-back', label: 'Pelvic Region', x: 150, y: 400 },
    { id: 'arm-left-back', label: 'Left Arm (Back)', x: 70, y: 260 },
    { id: 'arm-right-back', label: 'Right Arm (Back)', x: 230, y: 260 },
    { id: 'hand-left-back', label: 'Left Hand (Back)', x: 40, y: 440 },
    { id: 'hand-right-back', label: 'Right Hand (Back)', x: 260, y: 440 },
    { id: 'leg-left-back', label: 'Left Leg (Back)', x: 120, y: 560 },
    { id: 'leg-right-back', label: 'Right Leg (Back)', x: 180, y: 560 },
    { id: 'foot-left-back', label: 'Left Foot (Back)', x: 120, y: 760 },
    { id: 'foot-right-back', label: 'Right Foot (Back)', x: 180, y: 760 }
  ];


  get points(): AnatomyPoint[] {
    return this.side === 'front' ? this.frontPoints : this.backPoints;
  }


  go(id: string) {
    // Programmatic redirection to a page/section
    this.router.navigate(['/region', id]);
  }

  navigateTo(part: string) {
    this.router.navigate(['/body', part]);
    // Example: /body/head or /body/heart
  }
}
