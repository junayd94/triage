import { AfterViewInit, Component, ElementRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';


interface Hotspot {
  id: string;
  x: number; // percentage across image width
  y: number; // percentage down image height
  size?: number;
  side: 'front' | 'back';
  icon?: string;
}

@Component({
  selector: 'app-anatomy',
  standalone: false,
  templateUrl: './anatomy.component.html',
  styleUrl: './anatomy.component.scss'
})
export class AnatomyComponent {

  side: 'front' | 'back' = 'front';
  defaultSize = 6; // percent width

  hotspots: Hotspot[] = [
    // FRONT (left half of image: x = 0–50)
    { id: 'head', x: 25, y: 6, side: 'front', size: 8, icon: 'Head' },
    { id: 'lungs', x: 25, y: 25, side: 'front', size: 12, icon: 'Lungs' },
    { id: 'heart', x: 25, y: 33, side: 'front', size: 8, icon: 'Heart' },
    { id: 'kidneys', x: 25, y: 55, side: 'front', size: 10, icon: 'Kidneys' },

    // BACK (right half of image: x = 50–100)
    { id: 'head-back', x: 75, y: 6, side: 'back', size: 8, icon: 'Back Pain' },
    { id: 'kidneys-back', x: 75, y: 55, side: 'back', size: 12, icon: 'Kidneys' }
  ];

  get currentHotspots() {
    return this.hotspots.filter(h => h.side === this.side);
  }

  navigate(id: string) {
    console.log('Clicked:', id);
    // Here you can route to another page or open a detail modal
  }
}